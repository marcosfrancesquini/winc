'use strict';

// JS comparing arrays exercise solution

const readingList = ['How-to code', 'JavaScript 101', 'Why JS is so cool'];
const bookList = ['How-to code', 'JavaScript 101', 'Why JS is so cool'];

const compareArraysWithStringify = (a, b) => JSON.stringify(a) === JSON.stringify(b);

console.log(compareArraysWithStringify(readingList, bookList)); // true



// Part 2

const compareArraysWithEvery = (a, b) => a.length === b.length && a.every((e, i) => e === b[i]);

console.log(compareArraysWithEvery(readingList, bookList)); // true