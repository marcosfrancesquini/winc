'use strict';

const util = require('node:util');
const studentList = require('./mockData.js').studentList;
const attendanceList = require('./mockData.js').attendanceList;

console.log(util.isDeepStrictEqual(studentList, attendanceList)); // true